/*
DWAYNE FRASER
HOMEWORK 4.3
 */

package q3;

import java.awt.geom.*;
import java.awt.*;

public class BarGraph implements Chart, Cloneable {
	
    public BarGraph(Color color, double min, double max, double val) {
            this.color = color;		
            setData(min, max, val);
	}
	
        public double getData() {
            return value;
	}
	

	public double getMin() {
            return min;
	}
	

	public double getMax() {
            return max;
	}
        
	public void setData(double min, double max, double val) {
            this.min = min;
            this.max = max;
            this.value = val; 
	}
	
	public void setData(double val) {
            this.value = val; 
	}
    

    Color getColor() {
        return color;
    }

    public void draw(Rectangle r, Graphics2D g) {
        double relwidth = (value - min) / (max - min);
        double barwidth = relwidth * r.getWidth();
        Rectangle2D.Double r2 = new Rectangle2D.Double(r.getX(), r.getY(), 
        barwidth, r.getHeight());

        g.setColor(color);
        g.fill(r2);				
    }

    public BarGraph clone() {
        return new BarGraph(color, min, max, value);
    }

    private Color color;
    private double min;
    private double max;
    private double value;
}


