/*
DWAYNE FRASER
HOMEWORK 4.3
 */

package q3;

import java.awt.geom.Rectangle2D;
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Rectangle;

public class BarGraph3D extends BarGraph {
    
    public BarGraph3D(Color col, double min, double max, double val) {
        super(col, min, max, val);
    }

    public void draw(Rectangle r, Graphics2D g) {
        double relwidth = (getData() - getMin()) / (getMax() - getMin());
        double barwidth = relwidth * r.getWidth();
        Rectangle2D.Double r2 = new Rectangle2D.Double(r.getX(), r.getY(), 
        barwidth, r.getHeight());

        g.setColor(getColor());
        g.fill3DRect((int)r.getX(), (int)r.getY(), (int)barwidth, (int)r.getHeight(), true);
    }
}


