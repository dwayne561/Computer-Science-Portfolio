/*
DWAYNE FRASER
HOMEWORK 4.3
 */

package q3;


import java.awt.Graphics2D;
import java.awt.Rectangle;


public interface Chart {

	void setData(double min, double max, double val);


	void setData(double val);

	double getData();

	public void draw(Rectangle where, Graphics2D g);	
}


