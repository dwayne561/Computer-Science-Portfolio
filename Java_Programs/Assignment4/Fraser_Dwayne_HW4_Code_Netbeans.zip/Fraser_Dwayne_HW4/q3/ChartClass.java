/*
DWAYNE FRASER
HOMEWORK 4.3
 */

package q3;

import java.awt.*;
import javax.swing.*;


public class ChartClass extends JPanel {

	public ChartClass(Chart chart) {
		super(true);
		this.chart = chart;
	}
	
	public void paintComponent(Graphics g) {
		super.paintComponent(g);  
		Rectangle rv = new Rectangle();

		getBounds(rv);
		
		Rectangle chartBounds = new Rectangle(0 + HGAP, 0 + VGAP, 
				(int)rv.getWidth()-2*HGAP, (int)rv.getHeight() - 2*VGAP);
		
		chart.draw(chartBounds, (Graphics2D)g);
	}
	
	public void setData(double val) {
		chart.setData(val);
	}
	
	private Chart chart;
	private final static int HGAP = 8;
	private final static int VGAP = 8;	
}

