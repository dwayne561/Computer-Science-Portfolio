/*
DWAYNE FRASER
HOMEWORK 4.3
 */

package q3;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import java.awt.BorderLayout;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import javax.swing.BoxLayout;

public class ChartPanelSet extends JFrame {

    public ChartPanelSet(Chart[] charts) {
        int i;
        int x = charts.length;

        JPanel jpChartPanels = new JPanel();
        jpChartPanels.setLayout(new BoxLayout(jpChartPanels, BoxLayout.Y_AXIS));

        ChartClass []panels = new ChartClass[x];
        for (i=0; i<x;i++) {
                panels[i] = new ChartClass(charts[i]);
                jpChartPanels.add(panels[i]);			
        }

        JPanel jpNumbers = new JPanel();
        jpNumbers.setLayout(new BoxLayout(jpNumbers, BoxLayout.Y_AXIS));

        for (i=0; i<x; i++) {
                double val = charts[i].getData();


                JTextField jtfNumber = new JTextField(""+val, 6);


                jtfNumber.addKeyListener(new NumberKeyListener(jtfNumber, panels[i]));
                jpNumbers.add(jtfNumber);
        }

        setLayout(new BorderLayout());
        add(jpNumbers, BorderLayout.EAST);
        add(jpChartPanels, BorderLayout.CENTER);

        add(new JLabel("Keep numbers in [0,100]"), BorderLayout.NORTH);
    }

    private class NumberKeyListener implements KeyListener {
        public NumberKeyListener(JTextField tf, ChartClass chartPanel) {
                this.jtfNumber = tf;
                this.chartPanel = chartPanel;
        }

        @Override
        public void keyPressed(KeyEvent e) {
        }

        @Override
        public void keyReleased(KeyEvent e) {			
            try {

                    double val = Double.parseDouble(jtfNumber.getText());

                    chartPanel.setData(val);	
                    chartPanel.repaint();
            } catch (Exception ex) {

                    jtfNumber.selectAll();
            }
        }

        public void keyTyped(KeyEvent e) {
        }

        private JTextField jtfNumber;
        private ChartClass chartPanel;
    }	
}

