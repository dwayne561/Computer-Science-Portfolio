/*
DWAYNE FRASER
HOMEWORK 4.3
 */

package q3;

import javax.swing.*;
import java.awt.Color;
import java.awt.Dimension;

public class Main {

	public static void main(String[] args) {

		Color[] chartColors = new Color[]{Color.green, Color.blue, Color.orange};
		int x = chartColors.length;
		
		Chart[] charts = new Chart[x];
		int i;
		
		for (i=0; i<x/2; ++i) {
			charts[i] = new BarGraph3D(chartColors[i], 0, 100, 50);			
		}

                
		for (i=x/2; i<x; ++i) {
			charts[i] = new BarGraph3D(chartColors[i], 0, 100, 50);			
		}
		
		ChartPanelSet y = new ChartPanelSet(charts);
                
		y.setPreferredSize(new Dimension(600,200));
                
		y.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                
		y.pack();
		y.setVisible(true);
	}
}

