/*
DWAYNE FRASER
HOMEWORK Ch 6.3
 */

package q4;

public class Employee
{
   public Employee(String aName) { name = aName; }
   public void setSalary(double aSalary) { salary = aSalary; }
   public String getName() { return name; }
   public double getSalary() { return salary; }

    public String toJson() {
        
    StringBuilder x = new StringBuilder();

    x.append(getName());

    x.append(getSalary());

    return x.toString();
    
    }
    
   private final String name;
   private double salary;
}
