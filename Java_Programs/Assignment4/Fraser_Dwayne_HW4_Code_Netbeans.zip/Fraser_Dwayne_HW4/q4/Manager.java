/*
DWAYNE FRASER
HOMEWORK Ch 6.3
 */

package q4;

public class Manager extends Employee {

    public Manager(String aName) {
    super(aName);
    }
    
    public void setBonus(double b) {
    bonus = b;
    }

    public double getSalary() {
    return super.getSalary() + bonus;
    }

    private double bonus;
    
    public static void main(String[] args) {

        Employee sarah = new Employee("Sarah");
        sarah.setSalary(50000);

        Manager sandy = new Manager("Sandy");

        sandy.setSalary(100000);
        sandy.setBonus(1234);

        System.out.println(sarah.toJson());
        // prints {"class":"Employee", "name":"Sarah", "salary": 50000}
        System.out.println(sandy.toJson());
        // prints {"class":"Manager", "name":"Sandy", "salary": 101234, "bonus":1234} 

    }
}

 
