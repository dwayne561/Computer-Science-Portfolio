/*
DWAYNE FRASER
HOMEWORK Ch 6.4
 */

package q5;

public abstract class Aircraft {

    public void runSimulator() {
       takeOff();
       fly();
       land();
    }
    
    public abstract void takeOff();
    public abstract void fly();
    public abstract void land();
    
}



