/*
DWAYNE FRASER
HOMEWORK Ch 6.4
 */

package q5;

public class Jet extends Aircraft {
    
    public void takeOff() {
        System.out.println("Success");
    }
    public void fly() {
        System.out.println("Success");
    }

    public void land() {
        System.out.println("Success");
    }
    
}
