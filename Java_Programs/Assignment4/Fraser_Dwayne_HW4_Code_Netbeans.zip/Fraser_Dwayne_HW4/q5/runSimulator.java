/*
DWAYNE FRASER
HOMEWORK Ch 6.4
 */

package q5;

public class runSimulator {
    
    public static void main(String[] args) {

    Aircraft x = new Airplane();
    x.runSimulator();

    Aircraft y = new Jet();
    y.runSimulator();

    Aircraft z = new Helicopter();
    z.runSimulator(); 
    
    }
}
