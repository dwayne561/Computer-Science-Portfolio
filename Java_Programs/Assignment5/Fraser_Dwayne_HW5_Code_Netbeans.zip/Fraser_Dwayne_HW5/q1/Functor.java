/*
DWAYNE FRASER
HOMEWORK 5
L.1
 */

package q1;

interface Functor<R,T> { 

    R apply(T param);
 }
