/*
DWAYNE FRASER
HOMEWORK 5
L.1
 */

package q1;

public interface Functor2 <R,T1,T2> {
	R apply(T1 t1, T2 t2); 
}
