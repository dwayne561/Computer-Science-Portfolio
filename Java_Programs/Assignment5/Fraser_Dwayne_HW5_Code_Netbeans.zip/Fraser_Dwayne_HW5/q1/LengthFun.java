/*
DWAYNE FRASER
HOMEWORK 5
L.1
 */

package q1;

public class LengthFun implements Functor <Integer, String> {

    private static void print(String x) {
	System.out.println(x);
    }
    
    /*
    Apply Function
     */
    
    @Override
    public Integer apply(String y) {
            return y.length();
    }
    
    public static void main(String[] args) {
    	
        String str = "Test String";
        
	LengthFun x = new LengthFun();
		
	Integer y = x.apply(str);
		
	print(str + y);

	// Lambda:
	Functor<Integer, String> z = string -> string.length();
	print(str + z.apply(str));


	
    }
}
