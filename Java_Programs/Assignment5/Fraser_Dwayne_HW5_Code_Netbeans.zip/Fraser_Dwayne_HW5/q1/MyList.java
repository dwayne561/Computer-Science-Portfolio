/*
DWAYNE FRASER
HOMEWORK 5
L.1
 */

package q1;

import java.util.LinkedList;
import java.util.Arrays;



public class MyList <T> extends LinkedList <T> {
	
    private static final long serialVersionUID = 1L;

	public MyList() {
		super();
	}


	public <R> MyList <R> map(Functor <? extends R,? super T> fo) {
		
            MyList <R> x = new MyList<R>();
                
		for (T e: this) {
			x.add(fo.apply(e));
		}
		return x;
	}
        

	public T reduce(Functor2 <T,T,T> func, T initval) {
		T val = initval;
		for (T e:this) {
			val = func.apply(val, e);
		}
		return val;
	}


    private static void print(String s) {
	System.out.println(s);
    }


    public static void main(String[] args) {


	TimesTwoFun X = new TimesTwoFun();
	MyList<Integer> Y = new MyList<>();
	Y.addAll(Arrays.asList(-2,1,0,4));
		
	MyList <Integer> list1 = Y.map(X);		
	print(Y + " returns " + list1);


	MyList <Integer> list2 = Y.map(x -> 2 * x);
	print(Y + " returns " + list2);


	Summer summer = new Summer();

	MyList<Integer> summerlist = new MyList<>();
	summerlist.addAll(Arrays.asList(3, -1, 1, 4));

	Integer sumOfAll = summerlist.reduce(summer, 0);
	print(summerlist + " with " + summer.getClass() + " = " + sumOfAll);

	Integer sumOfAll2 = summerlist.reduce((x,y) -> x + y, 0);
	print(summerlist + " with lambda = " + sumOfAll2);

    }
}

class TimesTwoFun implements Functor<Integer, Integer> {
	@Override
	public Integer apply(Integer param) {
		return param * 2;

	}
}

class Summer implements Functor2<Integer,Integer,Integer> {
	@Override
	public Integer apply(Integer t1, Integer t2) {
	    return  t1 + t2;  
	}
}