/*
DWAYNE FRASER
HOMEWORK 5
10.1
 */

package q2;

import java.util.Collection;

public interface MyQueue <E> {

	E head();


	E dequeue();


	void enqueue(E e);

	/**
	 * returns the size of the queue
	 * @return the size of the queue
	 */
        
	int size();

	/**
	 * returns true if the queue is empty
	 * @return true if the queue is empty
	 */
	boolean isEmpty();

	void addAll(Collection <? extends E> c);	
}