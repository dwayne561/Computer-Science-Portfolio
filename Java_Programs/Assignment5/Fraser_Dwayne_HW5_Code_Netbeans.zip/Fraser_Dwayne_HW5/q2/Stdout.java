/*
DWAYNE FRASER
HOMEWORK 5
10.2
 */

package q2;

import java.io.PrintStream;


public class Stdout {

	static private Stdout theInstance = null;
	

	private PrintStream stdoutStream = null;
	

	private Stdout() {
		this.stdoutStream = System.out;
	}

	public void println(String s) {
		this.stdoutStream.println(s);
	}
	

	public static Stdout getInstance() {
		if (theInstance == null) {
			theInstance = new Stdout();
		}
		return theInstance;
	}
	

	public static void main(String[] args) {
		
		
		Stdout stdout = Stdout.getInstance();
		stdout.println("testing...testing...testing...");
	}

}
