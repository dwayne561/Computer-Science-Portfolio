/*
DWAYNE FRASER
HOMEWORK 5
7.1
 */

package q3;

import  java.io.Serializable;

public class Pair <K, V> implements Serializable, Cloneable {
    private final static long serialVersionUID = 1;

    public Pair(K k, V v) {
	this.key = k;
	this.value = v;
    }

    private Pair() {
    }

    public K k() { return key; }
    
    public V v() { return value; }


    public boolean equals(Object otherObject) {
	if (this == otherObject) return true; 
	if (otherObject == null) return false; 
	if (getClass() != otherObject.getClass()) return false; 

	Pair <?,?> other = (Pair <?,?>)otherObject;
	return k().equals(other.k()) && v().equals(other.v());
    }


    public int hashCode() {
	return 13 * k().hashCode() + v().hashCode();
    }

    public String toString() {
	return k().toString() + ":" + v().toString();
    }

    public Object clone() {

	Pair <K,V> copy = new Pair <K,V>(k(), v()); 

	return copy;
	

    }
    
    
    private K key;
    private V value;
}

