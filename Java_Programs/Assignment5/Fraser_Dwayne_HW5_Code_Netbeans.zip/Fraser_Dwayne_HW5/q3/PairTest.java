/*
DWAYNE FRASER
HOMEWORK 5
7.1
 */

package q3;

import java.io.*;

public class PairTest {
    public static void main(String[] args) {
        
	Pair <Integer, String> x = new Pair <Integer, String>(1, "one");
	Pair <Integer, String> y = new Pair <Integer, String>(1, "onetwo");
	Pair <Integer, String> z = new Pair <Integer, String>(1, "one");

	assert z.equals(x): "Fail";
	assert ! z.equals(y): "Fail";

	String filename = "serialized.dat";
	try {
	    ObjectOutputStream os = new ObjectOutputStream(new FileOutputStream(filename));
	    os.writeObject(z);
	    os.close();

	    ObjectInputStream in = new ObjectInputStream(new FileInputStream(filename));
	    Pair <Integer, String> p1restored = (Pair <Integer, String>) in.readObject();
	    assert z.equals(p1restored): "Fail";
	} catch (Exception ex) {
	    ex.printStackTrace(System.err);
	}

	Pair <Integer, String> p1copy = (Pair <Integer, String>) z.clone();
	assert z.equals(p1copy): "Fail";
	assert z.hashCode() == p1copy.hashCode(): "Fail";

    }
}

