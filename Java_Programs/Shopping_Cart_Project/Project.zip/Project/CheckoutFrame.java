package Project;


import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

public class CheckoutFrame extends JFrame implements ActionListener {
    DashboardFrame dframe = new DashboardFrame();
    List<String> cartlist = dframe.getList();
    String str = cartlist.toString();
    
    
    Container container = getContentPane();
    JLabel itemAvailLabel = new JLabel("Items In Cart:  ");
    JLabel itemLabel = new JLabel("Apple, Orange, Banana");
    JLabel priceLabel = new JLabel("$5, $10, $15");
    JLabel quantityLabel = new JLabel("20, 25, 50");
    JButton resetButton = new JButton("Checkout");

    CheckoutFrame() {
        List<String> cartlist = dframe.getList();
        String str = cartlist.toString();
        JLabel itemLabel = new JLabel(str);
        setLayoutManager();
        setLocationAndSize();
        addComponentsToContainer();
        addActionEvent();

    }

    public void setLayoutManager() {
        container.setLayout(null);
    }

    public void setLocationAndSize() {
        itemAvailLabel.setBounds(50, 150, 300, 30);
        itemLabel.setBounds(50, 190, 300, 30);
        priceLabel.setBounds(50, 220, 300, 30);
        quantityLabel.setBounds(50, 250, 300, 30);
        resetButton.setBounds(200, 300, 100, 30);
    }

    public void addComponentsToContainer() {
        container.add(itemAvailLabel);
        container.add(itemLabel);
        container.add(priceLabel);
        container.add(quantityLabel);
        container.add(resetButton);
    }

    public void addActionEvent() {
        resetButton.addActionListener(this);
    }


    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == resetButton) {
            JOptionPane.showMessageDialog(this, "Checkout Successful");
        }
    }
}
