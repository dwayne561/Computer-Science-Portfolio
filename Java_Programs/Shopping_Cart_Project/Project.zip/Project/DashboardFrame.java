package Project;


import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;


public class DashboardFrame extends JFrame implements ActionListener {
    
    Container container = getContentPane();
    JLabel itemAvailLabel = new JLabel("Items Available:  ");
    JLabel item1Label = new JLabel("Apple - Price: $5 (Stock 20)");
    JLabel item2Label = new JLabel("Orange - Price: $10 (Stock 25)");
    JLabel item3Label = new JLabel("Banana - Price: $15 (Stock 30)");
    JButton item1Button = new JButton("Add Item");
    JButton item2Button = new JButton("Add Item");
    JButton item3Button = new JButton("Add Item");
    JButton CheckoutButton = new JButton("View Cart");
    
    
    //Creating a List of type String using ArrayList  
    public List<String> list=new ArrayList<>();  

    DashboardFrame() {
        setLayoutManager();
        setLocationAndSize();
        addComponentsToContainer();
        addActionEvent();


    }
    public List<String> getList() {
        return list;
    }
    public void setLayoutManager() {
        container.setLayout(null);
    }

    public void setLocationAndSize() {
        itemAvailLabel.setBounds(50, 100, 300, 30);
        item1Label.setBounds(50, 150, 300, 30);
        item2Label.setBounds(350, 150, 300, 30);
        item3Label.setBounds(650, 150, 300, 30);
        item1Button.setBounds(50, 200, 100, 30);
        item2Button.setBounds(350, 200, 100, 30);
        item3Button.setBounds(650, 200, 100, 30);
        CheckoutButton.setBounds(200, 300, 100, 30);
    }

    public void addComponentsToContainer() {
        container.add(itemAvailLabel);
        container.add(item1Label);
        container.add(item2Label);
        container.add(item3Label);
        container.add(item1Button);
        container.add(item2Button);
        container.add(item3Button);
        container.add(CheckoutButton);
    }

    public void addActionEvent() {
        item1Button.addActionListener(this);
        item2Button.addActionListener(this);
        item3Button.addActionListener(this);
        CheckoutButton.addActionListener(this);
    }


    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == item1Button) {
            JOptionPane.showMessageDialog(this, "Succesfully Added");
            list.add("Apple");  
        }
        if (e.getSource() == item2Button) {
            JOptionPane.showMessageDialog(this, "Succesfully Added");
            list.add("Orange");
        }
        if (e.getSource() == item3Button) {
            JOptionPane.showMessageDialog(this, "Succesfully Added");
            list.add("Banana");
        }
        if (e.getSource() == CheckoutButton) {
            CheckoutFrame cframe = new CheckoutFrame();
            cframe.setTitle("Checkout Form");
            cframe.setVisible(true);
            cframe.setBounds(100, 100, 500, 750);
            cframe.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            cframe.setResizable(false);
        }
    }
}
